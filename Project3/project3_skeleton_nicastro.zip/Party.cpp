// CSCI 1300 Fall 2022
// Author: Graham Toothman and Rodrigo Nicastro
// Recitation: 201 – Elise Tate
// Project 3 - Code Skeleton

#include <iostream>
#include "Party.h"
using namespace std;

Party::Party(){
    numRoomsCleared = 0;
    numKeysFound = 0;
    ingredients = 0;
    armor = 0;
    gold = 100;
    partySize = 5;

    teammates[0] = Player();
    teammates[1] = Player();
    teammates[2] = Player();
    teammates[3] = Player(); 

    cookware = Cookware();
}

int Party::getRoomsCleared(){
    return numRoomsCleared;
}

int Party::getKeysFound(){
    return numKeysFound;
}

int Party::getGold(){
    return gold;
}

int Party::getArmor(){
    return armor;
}

int Party::getIngredients(){
    return ingredients;
}

int Party::getPartySize(){
    return partySize;
}

void Party::setRoomsCleared(int updateRoomsCleared){
    numRoomsCleared = updateRoomsCleared;
}

void Party::setKeysFound(int updateKeysFound){
    numKeysFound = updateKeysFound;
}

void Party::setGold(int updateGold){
    gold = updateGold;
}

void Party::setArmor(int updateArmor){
    armor = updateArmor;
}

void Party::setIngredients(int updateIngredients){
    ingredients = updateIngredients;
}

void Party::setPartySize(int inputSize){
    partySize = inputSize;
}

void Party::misfortune(){
    //1. Generate a random number between 0-9. If this number is less or equal to 3, complete the following steps. If it is greater than 3, nothing happens;
    //2. Generate another random number between 0-9;
    //3. If the random number is less or equal to 2, complete the following steps:
            //1. Print: "OH NO! Your team was robbed by dungeon bandits!";
            //2. Generate a random number between 0-2;
            //3. If the random number equals 0, remove 10kg of ingredients and print "You lost 10 kg of ingredients!";
            //4. If the random number equals 1, remove 1 random cookware item and print "You lost 1 <cookware_item>!";
            //5. If the random number equals 2, remove 1 armor from a random party member and print "<party_member> lost their armor!";
    
    //4. If the random number is equal to 3, complete the following steps:
            //1. Generate a random number between 0-1;
            //2. If the random number equals 0, one random party member loses their armor, and print "OH NO! <party_member>'s armor broke!";
            //3. If the random number equals 1, one random party member loeses their weapon, and print "OH NO! <party_member>'s <weapon_name> broke!";

    //5. If the random number is between 4 and 6 (inclusive), complete the following steps:
            //1. Remove 10 points of hunger from a random pary member;
            //2. If this causes the party member to reach 0 fullness, they die from hunger;            

    //6. If the random number is between 7 and 9 (inclusive), complete the following steps:
            //1. If the previous action was trying to open a door with a key, complete the following steps. If not, nothing happens;
            //2. Select a random teammate (never the party leader);
            //3. Remove this teammate's weapon and armor from the party's inventory;
            //4. Print "OH NO! Your teammate <party_member> is trapped in the previous room and is unable to get through. You must continue without them";
            //5. Update the party's size;
            //6. Print "Your party size has reduced to <party_size> members."
}

void Party::fight(){
    /**
 * This function executes a fight between the party and a monster of the current rating
 * 1. Pick a monster of the current challenge rating and display encounter message
 * 2. Give the player the choice to attack or surrender if applicable
 * 3. If they attack calculate the result of the battle using the necessary variables 
 * 4. If greater than 0 set the monster to dead and determine/apply the players reward
 * 5. If the players lose roll a death check on each of the party members except the leader
 * 6. Print win message and return
 * 7. If the party surrendered choice one party member to die and roll hunger checks on the rest
 * 8. Print loss message and return
*/

}