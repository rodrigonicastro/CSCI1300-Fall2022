// CSCI 1300 Fall 2022
// Author: Graham Toothman and Rodrigo Nicastro
// Recitation: 201 – Elise Tate
// Project 3 - Code Skeleton

#include <iostream>
#include "Player.h"
#include "Cookware.h"
using namespace std;

class Party{
    private:
        int partySize;
        int numRoomsCleared;
        int numKeysFound;
        int gold;
        int armor;
        int ingredients;
        Player teammates[4];
        Cookware cookware;

    public:
        Party();
        int getRoomsCleared();
        int getKeysFound();
        int getGold();
        int getArmor();
        int getIngredients();
        int getPartySize();
        void setRoomsCleared(int);
        void setKeysFound(int);
        void setGold(int);
        void setArmor(int);
        void setIngredients(int);
        void setPartySize(int);
        void misfortune();
        void fight();
};