// CSCI 1300 Fall 2022
// Author: Graham Toothman and Rodrigo Nicastro
// Recitation: 201 – Elise Tate
// Project 3 - Code Skeleton

#include <iostream>
#include "Cookware.h"
using namespace std;

Cookware::Cookware(){
    numPots = 0;
    numCauldrons = 0;
    numCauldrons = 0;
}

int Cookware::getPot(){
    return numPots;
}

int Cookware::getPan(){
    return numPans;
}

int Cookware::getCauldron(){
    return numCauldrons;
}

void Cookware::setPot(int updatePot){
    numPots = updatePot;
}

void Cookware::setPan(int updatePan){
    numPans = updatePan;
}

void Cookware::setCauldron(int updateCauldron){
    numCauldrons = updateCauldron;
}

void Cookware::cook(){
    //1. Ask the user which cookware and how many ingredients they want to use;
        //1. If they choose Ceramic Pot, generate a random number between 0-99;
            //1. If this number is equal or less than 25, remove the Ceramic Pot and the number of ingredients they chose from their inventory, and print "OH NO! Your Ceramic Pot broke! You lost <x> kg of ingredients!";
            //2. If this number is greater then 25, print: "Your cook was successful!", and increase fullness of each party member by <num_ingredients_used/5>;
        
        //2. If they choose Frying Pan, generate a random number between 0-9;
            //1. If this number is equal to 0, remove the Frying Pan and the number of ingredients they chose from their inventory, and print "OH NO! Your Frying Pan broke! You lost <x> kg of ingredients!";
            //2. If this number is greater then 0, print: "Your cook was successful!", and increase fullness of each party member by <num_ingredients_used/5>;    

        //3. If they choose Cauldron, generate a random number between 0-99;
            //1. If this number is equal to 0 or 1, remove the Cauldron and the number of ingredients they chose from their inventory, and print "OH NO! Your Cauldron broke! You lost <x> kg of ingredients!";
            //2. If this number is greater then 1, print: "Your cook was successful!", and increase fullness of each party member by <num_ingredients_used/5>;    

        //4. Print the fullness level of each party member and how many ingredients the party has left;
}